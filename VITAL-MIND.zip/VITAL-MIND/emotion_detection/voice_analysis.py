import librosa
import numpy as np
import os
from typing import Dict, List, Optional, Tuple

class VoiceEmotionAnalyzer:
    """
    A class to analyze voice recordings and detect emotions.
    Uses audio features like pitch, energy, zero-crossing rate, and spectral features
    to classify emotions in speech.
    """
    
    def __init__(self):
        """Initialize the voice emotion analyzer."""
        # Emotion feature reference values (simplified for demo purposes)
        # These are baseline features for different emotions
        self.emotion_references = {
            'happy': {
                'pitch_mean': 220.0,
                'pitch_std': 50.0,
                'energy': 0.7,
                'speech_rate': 1.2,
                'spectral_flux': 0.6
            },
            'sad': {
                'pitch_mean': 180.0,
                'pitch_std': 20.0,
                'energy': 0.4,
                'speech_rate': 0.8,
                'spectral_flux': 0.3
            },
            'angry': {
                'pitch_mean': 250.0,
                'pitch_std': 70.0,
                'energy': 0.8,
                'speech_rate': 1.3,
                'spectral_flux': 0.7
            },
            'surprised': {
                'pitch_mean': 280.0,
                'pitch_std': 60.0,
                'energy': 0.7,
                'speech_rate': 1.1,
                'spectral_flux': 0.5
            },
            'neutral': {
                'pitch_mean': 200.0,
                'pitch_std': 30.0,
                'energy': 0.5,
                'speech_rate': 1.0,
                'spectral_flux': 0.4
            },
            'fear': {
                'pitch_mean': 230.0,
                'pitch_std': 60.0,
                'energy': 0.6,
                'speech_rate': 1.2,
                'spectral_flux': 0.5
            }
        }
    
    def analyze_audio(self, audio_file: str) -> Dict[str, float]:
        """
        Analyze audio file to detect emotions.
        
        Args:
            audio_file: Path to the audio file
            
        Returns:
            Dictionary of emotion probabilities
        """
        # Default emotions with neutral at 100%
        emotions = {
            'happy': 0.0,
            'sad': 0.0,
            'angry': 0.0,
            'surprised': 0.0,
            'neutral': 100.0,
            'fear': 0.0
        }
        
        try:
            # Extract audio features
            features = self._extract_audio_features(audio_file)
            if features:
                # Calculate emotion scores based on features
                emotions = self._calculate_emotion_scores(features)
        except Exception as e:
            print(f"Error analyzing audio: {e}")
        
        return emotions
    
    def _extract_audio_features(self, audio_file: str) -> Optional[Dict[str, float]]:
        """
        Extract relevant audio features for emotion analysis.
        
        Args:
            audio_file: Path to the audio file
            
        Returns:
            Dictionary of audio features
        """
        # Check if file exists
        if not os.path.exists(audio_file):
            return None
        
        try:
            # Load the audio file
            y, sr = librosa.load(audio_file, sr=None)
            
            # Extract pitch information
            pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
            pitch_values = []
            for i in range(pitches.shape[1]):
                index = magnitudes[:, i].argmax()
                pitch = pitches[index, i]
                if pitch > 0:  # Filter out zero pitch values
                    pitch_values.append(pitch)
            
            pitch_mean = np.mean(pitch_values) if pitch_values else 0
            pitch_std = np.std(pitch_values) if pitch_values else 0
            
            # Extract energy/volume
            energy = np.mean(librosa.feature.rms(y=y)[0])
            
            # Extract speech rate (approximated by zero crossing rate)
            zcr = np.mean(librosa.feature.zero_crossing_rate(y=y)[0])
            speech_rate_indicator = zcr
            
            # Extract spectral flux (indicator of voice variability)
            hop_length = 512
            spec = np.abs(librosa.stft(y, hop_length=hop_length))
            spectral_flux = np.mean(librosa.onset.onset_strength(y=y, sr=sr))
            
            # Create a features dictionary
            features = {
                'pitch_mean': pitch_mean,
                'pitch_std': pitch_std,
                'energy': energy,
                'speech_rate': speech_rate_indicator,
                'spectral_flux': spectral_flux
            }
            
            return features
        
        except Exception as e:
            print(f"Error extracting audio features: {e}")
            return None
    
    def _calculate_emotion_scores(self, features: Dict[str, float]) -> Dict[str, float]:
        """
        Calculate emotion scores based on extracted audio features.
        
        Args:
            features: Dictionary of audio features
            
        Returns:
            Dictionary of emotion probabilities
        """
        emotions = {
            'happy': 0.0,
            'sad': 0.0,
            'angry': 0.0,
            'surprised': 0.0,
            'neutral': 0.0,
            'fear': 0.0
        }
        
        # Calculate similarity to each emotion reference
        similarities = {}
        for emotion, reference in self.emotion_references.items():
            # Compute weighted euclidean distance between features and reference
            distance = 0
            weights = {
                'pitch_mean': 0.3,
                'pitch_std': 0.2,
                'energy': 0.25,
                'speech_rate': 0.15,
                'spectral_flux': 0.1
            }
            
            for feature, weight in weights.items():
                # Normalize the feature by the reference value
                if reference[feature] > 0:
                    normalized_diff = (features[feature] - reference[feature]) / reference[feature]
                    distance += weight * (normalized_diff ** 2)
            
            # Convert distance to similarity (0 to 1 scale)
            similarity = np.exp(-distance)
            similarities[emotion] = similarity
        
        # Convert similarities to percentages
        total_similarity = sum(similarities.values())
        if total_similarity > 0:
            for emotion, similarity in similarities.items():
                emotions[emotion] = (similarity / total_similarity) * 100.0
        else:
            emotions['neutral'] = 100.0
        
        # Apply rules based on specific feature patterns
        
        # Happy: High pitch, high energy, moderate-high speech rate
        if features['pitch_mean'] > 210 and features['energy'] > 0.6 and features['speech_rate'] > 0.04:
            emotions['happy'] += 20.0
        
        # Sad: Low pitch, low energy, slow speech rate
        if features['pitch_mean'] < 190 and features['energy'] < 0.5 and features['speech_rate'] < 0.03:
            emotions['sad'] += 20.0
        
        # Angry: High pitch variation, high energy
        if features['pitch_std'] > 40 and features['energy'] > 0.7:
            emotions['angry'] += 20.0
        
        # Surprised: Very high pitch, moderate energy, rapid changes
        if features['pitch_mean'] > 250 and features['spectral_flux'] > 0.5:
            emotions['surprised'] += 20.0
        
        # Fear: Higher pitch than neutral, moderate energy, high variation
        if features['pitch_mean'] > 210 and features['pitch_std'] > 45 and features['energy'] > 0.5:
            emotions['fear'] += 20.0
        
        # Normalize to 100%
        total = sum(emotions.values())
        if total > 0:
            for emotion in emotions:
                emotions[emotion] = round((emotions[emotion] / total) * 100.0, 1)
        else:
            emotions['neutral'] = 100.0
        
        return emotions
