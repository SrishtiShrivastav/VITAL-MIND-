import cv2
import numpy as np
import mediapipe as mp
from typing import Dict, Tuple, Optional, List

class FacialEmotionAnalyzer:
    """
    A class to analyze facial expressions and detect emotions.
    Uses MediaPipe for facial landmark detection and a rule-based approach 
    to classify emotions based on facial features.
    """
    
    def __init__(self):
        """Initialize the facial emotion analyzer with MediaPipe face detection."""
        self.mp_face_mesh = mp.solutions.face_mesh
        self.mp_drawing = mp.solutions.drawing_utils
        self.mp_drawing_styles = mp.solutions.drawing_styles
        
        # Initialize face mesh with high confidence thresholds for reliable detection
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            static_image_mode=False,
            max_num_faces=1,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        
        # Facial landmark indices for different facial features
        self.landmark_indices = {
            'left_eye': [33, 133, 160, 159, 158, 144, 145, 153],
            'right_eye': [362, 263, 386, 387, 388, 373, 374, 380],
            'mouth': [61, 185, 40, 39, 37, 0, 267, 269, 270, 409, 291, 375, 321, 405, 314, 17, 84, 181, 91, 146],
            'left_eyebrow': [107, 55, 65],
            'right_eyebrow': [336, 285, 295],
            'nose': [168, 6, 197, 195, 5]
        }
        
        # Initialize emotion detection history for smoothing
        self.emotion_history = []
        self.history_length = 5  # Number of frames to consider for smoothing
    
    def analyze_frame(self, frame: np.ndarray) -> Tuple[Dict[str, float], np.ndarray]:
        """
        Analyze a frame to detect facial emotions.
        
        Args:
            frame: The input image frame from camera
            
        Returns:
            A tuple containing:
            - Dictionary of emotion probabilities
            - Processed frame with annotations
        """
        # Convert the BGR image to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Process the image and find faces
        results = self.face_mesh.process(rgb_frame)
        
        # Default emotions with neutral at 100%
        emotions = {
            'happy': 0.0,
            'sad': 0.0,
            'angry': 0.0,
            'surprised': 0.0,
            'neutral': 100.0,
            'fear': 0.0
        }
        
        # Create a copy of the frame for drawing
        annotated_frame = frame.copy()
        
        # If face landmarks are detected
        if results.multi_face_landmarks:
            face_landmarks = results.multi_face_landmarks[0]  # Get the first face
            
            # Draw the face mesh on the frame
            self.mp_drawing.draw_landmarks(
                image=annotated_frame,
                landmark_list=face_landmarks,
                connections=self.mp_face_mesh.FACEMESH_TESSELATION,
                landmark_drawing_spec=None,
                connection_drawing_spec=self.mp_drawing_styles.get_default_face_mesh_tesselation_style()
            )
            
            # Extract facial features and calculate emotion metrics
            emotions = self._extract_emotions_from_landmarks(face_landmarks, annotated_frame.shape)
            
            # Add current emotions to history for smoothing
            self.emotion_history.append(emotions)
            if len(self.emotion_history) > self.history_length:
                self.emotion_history.pop(0)  # Remove oldest entry
            
            # Smooth emotions over history
            smoothed_emotions = self._smooth_emotions()
            
            # Add text showing the dominant emotion
            dominant_emotion = max(smoothed_emotions.items(), key=lambda x: x[1])[0]
            cv2.putText(
                annotated_frame,
                f"Emotion: {dominant_emotion.capitalize()}",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )
            
            return smoothed_emotions, annotated_frame
        
        return emotions, annotated_frame
    
    def _extract_emotions_from_landmarks(self, face_landmarks, frame_shape) -> Dict[str, float]:
        """
        Extract emotions from facial landmarks.
        
        Args:
            face_landmarks: The detected face landmarks
            frame_shape: The shape of the input frame
            
        Returns:
            Dictionary of emotion probabilities
        """
        # Get the height and width of the frame
        height, width = frame_shape[:2]
        
        # Convert landmarks to numpy array of coordinates
        landmarks = []
        for landmark in face_landmarks.landmark:
            x, y = int(landmark.x * width), int(landmark.y * height)
            landmarks.append((x, y))
        landmarks = np.array(landmarks)
        
        # Calculate various facial metrics
        eye_aspect_ratio = self._calculate_eye_aspect_ratio(landmarks)
        mouth_aspect_ratio = self._calculate_mouth_aspect_ratio(landmarks)
        eyebrow_position = self._calculate_eyebrow_position(landmarks)
        
        # Initialize emotion scores
        emotions = {
            'happy': 0.0,
            'sad': 0.0,
            'angry': 0.0,
            'surprised': 0.0,
            'neutral': 0.0,
            'fear': 0.0
        }
        
        # Apply rule-based emotion detection
        
        # Happy: raised cheeks, slight smile
        if mouth_aspect_ratio > 0.2 and mouth_aspect_ratio < 0.5:
            emotions['happy'] = 70.0 + 30.0 * (mouth_aspect_ratio - 0.2) / 0.3
        
        # Sad: lowered eyebrows, slight frown
        if eyebrow_position < -0.05:
            emotions['sad'] = 50.0 + 50.0 * min(abs(eyebrow_position) / 0.1, 1.0)
        
        # Angry: lowered and drawn eyebrows
        if eyebrow_position < -0.03 and mouth_aspect_ratio < 0.15:
            emotions['angry'] = 60.0 + 40.0 * min(abs(eyebrow_position) / 0.1, 1.0)
        
        # Surprised: raised eyebrows, open mouth
        if eyebrow_position > 0.08 and eye_aspect_ratio > 0.25 and mouth_aspect_ratio > 0.4:
            emotions['surprised'] = 70.0 + 30.0 * min(mouth_aspect_ratio / 0.6, 1.0)
        
        # Fear: raised eyebrows, widened eyes, slightly open mouth
        if eyebrow_position > 0.05 and eye_aspect_ratio > 0.3 and mouth_aspect_ratio > 0.2 and mouth_aspect_ratio < 0.4:
            emotions['fear'] = 60.0 + 40.0 * min(eye_aspect_ratio / 0.4, 1.0)
        
        # Neutral: default state
        neutral_score = 100.0 - sum(emotions.values())
        emotions['neutral'] = max(neutral_score, 0.0)
        
        # Normalize to ensure the sum is 100%
        total = sum(emotions.values())
        if total > 0:
            for emotion in emotions:
                emotions[emotion] = (emotions[emotion] / total) * 100.0
        else:
            emotions['neutral'] = 100.0
        
        return emotions
    
    def _calculate_eye_aspect_ratio(self, landmarks: np.ndarray) -> float:
        """Calculate the eye aspect ratio to detect eye openness."""
        left_eye_points = [landmarks[i] for i in self.landmark_indices['left_eye']]
        right_eye_points = [landmarks[i] for i in self.landmark_indices['right_eye']]
        
        # Simplified calculation for demo purposes
        left_eye_height = np.linalg.norm(np.array(left_eye_points[1]) - np.array(left_eye_points[5]))
        left_eye_width = np.linalg.norm(np.array(left_eye_points[0]) - np.array(left_eye_points[4]))
        
        right_eye_height = np.linalg.norm(np.array(right_eye_points[1]) - np.array(right_eye_points[5]))
        right_eye_width = np.linalg.norm(np.array(right_eye_points[0]) - np.array(right_eye_points[4]))
        
        # Average aspect ratio of both eyes (height/width)
        if left_eye_width > 0 and right_eye_width > 0:
            left_ratio = left_eye_height / left_eye_width
            right_ratio = right_eye_height / right_eye_width
            return (left_ratio + right_ratio) / 2
        return 0.2  # Default value
    
    def _calculate_mouth_aspect_ratio(self, landmarks: np.ndarray) -> float:
        """Calculate the mouth aspect ratio to detect mouth openness."""
        mouth_points = [landmarks[i] for i in self.landmark_indices['mouth']]
        
        # Simplified calculation for demo purposes
        mouth_height = np.linalg.norm(np.array(mouth_points[3]) - np.array(mouth_points[9]))
        mouth_width = np.linalg.norm(np.array(mouth_points[0]) - np.array(mouth_points[6]))
        
        # Return mouth aspect ratio (height/width)
        if mouth_width > 0:
            return mouth_height / mouth_width
        return 0.1  # Default value
    
    def _calculate_eyebrow_position(self, landmarks: np.ndarray) -> float:
        """Calculate the eyebrow position relative to the eyes."""
        left_eyebrow = [landmarks[i] for i in self.landmark_indices['left_eyebrow']]
        right_eyebrow = [landmarks[i] for i in self.landmark_indices['right_eyebrow']]
        left_eye = [landmarks[i] for i in self.landmark_indices['left_eye']]
        right_eye = [landmarks[i] for i in self.landmark_indices['right_eye']]
        
        # Calculate average y-positions
        left_eyebrow_y = sum(p[1] for p in left_eyebrow) / len(left_eyebrow)
        right_eyebrow_y = sum(p[1] for p in right_eyebrow) / len(right_eyebrow)
        left_eye_y = sum(p[1] for p in left_eye) / len(left_eye)
        right_eye_y = sum(p[1] for p in right_eye) / len(right_eye)
        
        # Relative position (negative value means eyebrows are lower than usual)
        left_relative = (left_eye_y - left_eyebrow_y) / max(1, left_eye_y)
        right_relative = (right_eye_y - right_eyebrow_y) / max(1, right_eye_y)
        
        # Average of both eyebrows
        return (left_relative + right_relative) / 2
    
    def _smooth_emotions(self) -> Dict[str, float]:
        """Smooth emotion values over multiple frames to reduce jitter."""
        if not self.emotion_history:
            return {
                'happy': 0.0,
                'sad': 0.0,
                'angry': 0.0,
                'surprised': 0.0,
                'neutral': 100.0,
                'fear': 0.0
            }
        
        # Calculate weighted average (more recent frames have higher weight)
        weights = np.linspace(0.5, 1.0, len(self.emotion_history))
        weights = weights / np.sum(weights)  # Normalize weights
        
        smoothed = {emotion: 0.0 for emotion in self.emotion_history[0].keys()}
        
        for i, emotion_dict in enumerate(self.emotion_history):
            for emotion, value in emotion_dict.items():
                smoothed[emotion] += value * weights[i]
        
        # Ensure the sum is 100%
        total = sum(smoothed.values())
        if total > 0:
            for emotion in smoothed:
                smoothed[emotion] = round(smoothed[emotion] / total * 100.0, 1)
        
        return smoothed
