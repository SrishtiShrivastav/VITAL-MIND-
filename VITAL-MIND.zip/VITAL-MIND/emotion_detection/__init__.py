# Emotion detection package initialization
