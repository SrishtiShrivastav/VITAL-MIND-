import cv2
import plotly.graph_objects as go
from typing import Dict, List, Tuple, Optional

def draw_emotions_chart(emotions: Dict[str, float], title: str) -> go.Figure:
    """
    Create a chart visualization for emotions.
    
    Args:
        emotions: Dictionary of emotions and their percentage values
        title: Chart title
        
    Returns:
        Plotly figure object
    """
    # Sort emotions by percentage (descending)
    sorted_emotions = sorted(emotions.items(), key=lambda x: x[1], reverse=True)
    
    # Get labels and values
    labels = [emotion.capitalize() for emotion, _ in sorted_emotions]
    values = [value for _, value in sorted_emotions]
    
    # Assign colors for each emotion
    colors = {
        'Happy': '#FFC107',       # Amber
        'Sad': '#3F51B5',         # Indigo
        'Angry': '#F44336',       # Red
        'Surprised': '#9C27B0',   # Purple
        'Neutral': '#4CAF50',     # Green
        'Fear': '#607D8B'         # Blue Grey
    }
    
    # Create emotion colors list
    emotion_colors = [colors.get(label, '#9E9E9E') for label in labels]
    
    # Create bar chart
    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=labels,
        y=values,
        marker_color=emotion_colors
    ))
    
    # Update layout
    fig.update_layout(
        title=title,
        xaxis_title='Emotion',
        yaxis_title='Percentage (%)',
        yaxis=dict(range=[0, 100]),
        height=300
    )
    
    return fig

def combine_emotion_predictions(facial_emotions: Dict[str, float], voice_emotions: Dict[str, float]) -> Dict[str, float]:
    """
    Combine facial and voice emotion predictions with weighted average.
    
    Args:
        facial_emotions: Dictionary of facial emotion percentages
        voice_emotions: Dictionary of voice emotion percentages
        
    Returns:
        Dictionary of combined emotion percentages
    """
    # Weight for facial emotions (facial:voice ratio)
    facial_weight = 0.6
    voice_weight = 0.4
    
    # Initialize combined emotions
    combined = {}
    
    # Combine emotions with weighted average
    for emotion in facial_emotions:
        facial_value = facial_emotions.get(emotion, 0.0)
        voice_value = voice_emotions.get(emotion, 0.0)
        combined[emotion] = (facial_value * facial_weight) + (voice_value * voice_weight)
    
    # Ensure the sum is 100%
    total = sum(combined.values())
    if total > 0:
        for emotion in combined:
            combined[emotion] = round((combined[emotion] / total) * 100.0, 1)
    
    return combined

def check_devices() -> Tuple[bool, bool]:
    """
    Check if camera and microphone are available.
    
    Returns:
        Tuple of (camera_available, microphone_available)
    """
    # Check camera
    camera_available = False
    try:
        cap = cv2.VideoCapture(0)
        if cap.isOpened():
            camera_available = True
            cap.release()
    except:
        camera_available = False
    
    # We'll assume microphone is not available in this environment
    microphone_available = False
    
    return camera_available, microphone_available
