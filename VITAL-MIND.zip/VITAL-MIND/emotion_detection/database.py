import os
import psycopg2
from psycopg2 import sql
import datetime
from typing import Dict, List, Optional, Tuple
import json

class EmotionDatabase:
    """Database interface for storing and retrieving emotion data."""
    
    def __init__(self):
        """Initialize the database connection."""
        self.conn = None
        self.create_tables()
    
    def connect(self):
        """Connect to the PostgreSQL database."""
        if self.conn is None:
            try:
                # Connect using the DATABASE_URL environment variable
                self.conn = psycopg2.connect(os.environ.get('DATABASE_URL'))
                return True
            except Exception as e:
                print(f"Error connecting to database: {e}")
                return False
        return True
    
    def close(self):
        """Close the database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None
    
    def create_tables(self):
        """Create the necessary tables if they don't exist."""
        if not self.connect():
            return False
        
        try:
            with self.conn.cursor() as cur:
                # Create the sessions table
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS sessions (
                        id SERIAL PRIMARY KEY,
                        start_time TIMESTAMP NOT NULL DEFAULT NOW(),
                        end_time TIMESTAMP,
                        notes TEXT
                    )
                """)
                
                # Create the emotion_records table
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS emotion_records (
                        id SERIAL PRIMARY KEY,
                        session_id INTEGER REFERENCES sessions(id),
                        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
                        source VARCHAR(50) NOT NULL,
                        emotions JSONB NOT NULL
                    )
                """)
                
                # Create the heartbeat_records table for future use
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS heartbeat_records (
                        id SERIAL PRIMARY KEY,
                        session_id INTEGER REFERENCES sessions(id),
                        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
                        bpm INTEGER NOT NULL,
                        hrv FLOAT
                    )
                """)
                
                self.conn.commit()
                return True
        except Exception as e:
            print(f"Error creating tables: {e}")
            self.conn.rollback()
            return False
    
    def start_session(self, notes: Optional[str] = None) -> Optional[int]:
        """
        Start a new session for recording emotions.
        
        Args:
            notes: Optional notes about this session
            
        Returns:
            Session ID if successful, None otherwise
        """
        if not self.connect():
            return None
        
        try:
            with self.conn.cursor() as cur:
                # Create a new session
                if notes:
                    cur.execute(
                        "INSERT INTO sessions (notes) VALUES (%s) RETURNING id", 
                        (notes,)
                    )
                else:
                    cur.execute(
                        "INSERT INTO sessions DEFAULT VALUES RETURNING id"
                    )
                
                session_id = cur.fetchone()[0]
                self.conn.commit()
                return session_id
        except Exception as e:
            print(f"Error starting session: {e}")
            self.conn.rollback()
            return None
    
    def end_session(self, session_id: int) -> bool:
        """
        End a session by updating its end time.
        
        Args:
            session_id: ID of the session to end
            
        Returns:
            True if successful, False otherwise
        """
        if not self.connect():
            return False
        
        try:
            with self.conn.cursor() as cur:
                cur.execute(
                    "UPDATE sessions SET end_time = NOW() WHERE id = %s",
                    (session_id,)
                )
                self.conn.commit()
                return True
        except Exception as e:
            print(f"Error ending session: {e}")
            self.conn.rollback()
            return False
    
    def record_emotion(self, session_id: int, source: str, emotions: Dict[str, float]) -> bool:
        """
        Record emotion data for a session.
        
        Args:
            session_id: ID of the session
            source: Source of emotion data (e.g., 'facial', 'voice', 'combined')
            emotions: Dictionary of emotion percentages
            
        Returns:
            True if successful, False otherwise
        """
        if not self.connect():
            return False
        
        try:
            with self.conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO emotion_records (session_id, source, emotions) VALUES (%s, %s, %s)",
                    (session_id, source, json.dumps(emotions))
                )
                self.conn.commit()
                return True
        except Exception as e:
            print(f"Error recording emotion: {e}")
            self.conn.rollback()
            return False
    
    def get_session_emotions(self, session_id: int) -> List[Dict]:
        """
        Get all emotion records for a specific session.
        
        Args:
            session_id: ID of the session
            
        Returns:
            List of emotion records
        """
        if not self.connect():
            return []
        
        try:
            with self.conn.cursor() as cur:
                cur.execute(
                    "SELECT id, timestamp, source, emotions FROM emotion_records WHERE session_id = %s ORDER BY timestamp",
                    (session_id,)
                )
                
                records = []
                for row in cur.fetchall():
                    records.append({
                        'id': row[0],
                        'timestamp': row[1],
                        'source': row[2],
                        'emotions': json.loads(row[3])
                    })
                
                return records
        except Exception as e:
            print(f"Error retrieving session emotions: {e}")
            return []
    
    def get_recent_sessions(self, limit: int = 5) -> List[Dict]:
        """
        Get recent sessions with some emotion data.
        
        Args:
            limit: Maximum number of sessions to return
            
        Returns:
            List of session records
        """
        if not self.connect():
            return []
        
        try:
            with self.conn.cursor() as cur:
                cur.execute("""
                    SELECT s.id, s.start_time, s.end_time, s.notes,
                           COUNT(er.id) as record_count
                    FROM sessions s
                    LEFT JOIN emotion_records er ON s.id = er.session_id
                    GROUP BY s.id
                    ORDER BY s.start_time DESC
                    LIMIT %s
                """, (limit,))
                
                sessions = []
                for row in cur.fetchall():
                    sessions.append({
                        'id': row[0],
                        'start_time': row[1],
                        'end_time': row[2],
                        'notes': row[3],
                        'record_count': row[4]
                    })
                
                return sessions
        except Exception as e:
            print(f"Error retrieving recent sessions: {e}")
            return []
    
    def get_emotion_trends(self, days: int = 7) -> Dict[str, List]:
        """
        Get emotion trends over the specified number of days.
        
        Args:
            days: Number of days to look back
            
        Returns:
            Dictionary with dates and average emotions
        """
        if not self.connect():
            return {}
        
        try:
            with self.conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        DATE(timestamp) as date,
                        source,
                        jsonb_object_keys(emotions) as emotion,
                        AVG((emotions->>jsonb_object_keys(emotions))::float) as avg_value
                    FROM emotion_records
                    WHERE timestamp >= NOW() - INTERVAL %s DAY
                    GROUP BY date, source, emotion
                    ORDER BY date, source, emotion
                """, (days,))
                
                results = {}
                for row in cur.fetchall():
                    date_str = row[0].strftime('%Y-%m-%d')
                    source = row[1]
                    emotion = row[2]
                    avg_value = float(row[3])
                    
                    if date_str not in results:
                        results[date_str] = {}
                    
                    if source not in results[date_str]:
                        results[date_str][source] = {}
                    
                    results[date_str][source][emotion] = avg_value
                
                return results
        except Exception as e:
            print(f"Error retrieving emotion trends: {e}")
            return {}